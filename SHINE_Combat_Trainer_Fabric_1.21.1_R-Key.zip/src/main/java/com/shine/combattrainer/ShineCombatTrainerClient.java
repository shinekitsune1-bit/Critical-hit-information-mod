package com.shine.combattrainer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import org.lwjgl.glfw.GLFW;

public class ShineCombatTrainerClient implements ClientModInitializer {
    private static final double RANGE = 3.2;
    private static final int ATTACK_DELAY = 8;
    private static int cooldown = 0;
    private static boolean enabled = false;

    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = new KeyBinding(
                "key.shine_combat_trainer.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.shine_combat_trainer"
        );

        ClientTickEvents.END_CLIENT_TICK.register(ShineCombatTrainerClient::tick);
    }

    private static void tick(MinecraftClient client) {
        while (toggleKey.wasPressed()) {
            enabled = !enabled;
            if (client.player != null) {
                client.player.sendMessage(
                        net.minecraft.text.Text.literal(
                                "SHINE Combat Trainer: " + (enabled ? "ON" : "OFF")
                        ), true);
            }
        }

        if (!enabled || client.player == null || client.world == null ||
                client.interactionManager == null) return;

        if (cooldown > 0) cooldown--;

        Box box = client.player.getBoundingBox().expand(RANGE);
        LivingEntity target = client.world.getEntitiesByClass(
                LivingEntity.class,
                box,
                e -> e instanceof HostileEntity && e.isAlive() && e != client.player
        ).stream()
                .min((a, b) -> Double.compare(
                        client.player.squaredDistanceTo(a),
                        client.player.squaredDistanceTo(b)))
                .orElse(null);

        if (target == null || cooldown > 0) return;

        double dx = target.getX() - client.player.getX();
        double dz = target.getZ() - client.player.getZ();
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        client.player.setYaw(yaw);

        if (client.player.getAttackCooldownProgress(0.0f) >= 1.0f) {
            client.interactionManager.attackEntity(client.player, target);
            client.player.swingHand(Hand.MAIN_HAND);
            cooldown = ATTACK_DELAY;
        }
    }
}
