# SHINE Combat Trainer — Fabric 1.21.1

Practice-only combat trainer for Fabric 1.21.1.

- Press **R** to toggle the trainer ON/OFF.
- It targets nearby hostile mobs only.
- It uses Minecraft's normal attack cooldown.
- It does not target or attack players.

Build with JDK 21:
`./gradlew build`

The resulting JAR will be in `build/libs/`.
